package com.gappein.sdk.ui.view.channelview.`interface`

import com.gappein.sdk.model.User

interface OnChannelClick {

    fun onUserClick(user: User)

}