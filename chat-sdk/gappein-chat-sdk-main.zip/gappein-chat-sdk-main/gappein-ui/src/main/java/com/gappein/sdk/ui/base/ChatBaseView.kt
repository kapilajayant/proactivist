package com.gappein.sdk.ui.base

import com.gappein.sdk.client.ChatClient

interface ChatBaseView {

    fun getClient(): ChatClient

}