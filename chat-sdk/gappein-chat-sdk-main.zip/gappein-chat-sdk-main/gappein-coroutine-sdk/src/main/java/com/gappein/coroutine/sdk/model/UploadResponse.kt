package com.gappein.coroutine.sdk.model

data class UploadResponse(
    val url: String? = null,
    val progress: Int = 0
)