# Gappein

![SocialPreview](https://raw.githubusercontent.com/Gappein/Gappein-Chat-SDK/main/art/banner-chat-sdk.png)

[![Download Chat](https://api.bintray.com/packages/gappein/Gappein/Gappein-Chat-SDK/images/download.svg)](https://bintray.com/gappein/Gappein/Gappein-Chat-SDK/_latestVersion)
[![Download UI](https://api.bintray.com/packages/gappein/Gappein/Gappein-UI-SDK/images/download.svg)](https://bintray.com/gappein/Gappein/Gappein-UI-SDK/_latestVersion)

_**Gappein**_ is a new Chat SDK in town!

A plug and play modular toolkit for integrating the Chat feature on top of Firebase! 🔥

