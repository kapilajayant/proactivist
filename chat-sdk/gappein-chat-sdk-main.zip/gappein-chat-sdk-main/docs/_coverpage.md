![Icon](images/icon.png)

# Gappein <small>💬 Chat SDK</small>

> A plug and play modular toolkit for integrating the Chat feature on top of Firebase! 🔥

- Gappein is a new Chat SDK in town!

[Get Started](/?id=gappein)
[GitHub](https://github.com/Gappein/Gappein-Chat-SDK)
[Product Hunt](https://www.producthunt.com/posts/gappein-sdk?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-gappein-sdk)