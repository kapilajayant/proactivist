# Changelog

You can see [GitHub releases](https://github.com/Gappein/Gappein-Chat-SDK/releases) where this is officially released.

---
